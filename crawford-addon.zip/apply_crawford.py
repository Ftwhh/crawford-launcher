"""Adds Crawford accounts to the Amethyst source tree. Run from the Amethyst repo root."""
import os, re, shutil, sys

ADDON = os.path.dirname(os.path.abspath(__file__))
APP = "app_pojavlauncher"
JAVA = f"{APP}/src/main/java"

def patch(path, old, new, count=1):
    s = open(path, encoding="utf-8").read()
    if new in s:
        return
    if s.count(old) < 1:
        sys.exit(f"apply_crawford: could not find expected code in {path}:\n{old}")
    s = s.replace(old, new, count)
    open(path, "w", encoding="utf-8").write(s)
    print("patched", path)

# 1. Copy the Crawford classes in.
dst = f"{JAVA}/net/crawford"
os.makedirs(dst, exist_ok=True)
for f in os.listdir(f"{ADDON}/launcher/net/crawford"):
    shutil.copy(f"{ADDON}/launcher/net/crawford/{f}", dst)
    print("added", f"{dst}/{f}")

# 2. Supabase settings come from the build environment (GitHub secrets).
patch(f"{APP}/build.gradle",
      "        multiDexEnabled true //important\n",
      "        multiDexEnabled true //important\n"
      "        buildConfigField 'String', 'CRAWFORD_SUPABASE_URL', '\"' + (System.getenv('CRAWFORD_SUPABASE_URL') ?: '').trim() + '\"'\n"
      "        buildConfigField 'String', 'CRAWFORD_SUPABASE_KEY', '\"' + (System.getenv('CRAWFORD_SUPABASE_KEY') ?: '').trim() + '\"'\n")

# 3. "Crawford Account" button on the add-account screen.
layout = f"{APP}/src/main/res/layout/fragment_select_auth_method.xml"
patch(layout, 'android:layout_height="@dimen/_200sdp"', 'android:layout_height="@dimen/_260sdp"')
patch(layout,
      '''        android:text="Local account"
        android:textSize="@dimen/_12ssp"
        android:layout_marginHorizontal="@dimen/_25sdp"
        app:layout_constraintBottom_toBottomOf="@id/login_menu"''',
      '''        android:text="Local account"
        android:textSize="@dimen/_12ssp"
        android:layout_marginHorizontal="@dimen/_25sdp"
        android:layout_marginBottom="@dimen/_20sdp"
        app:layout_constraintBottom_toTopOf="@+id/button_crawford_account"''')
patch(layout,
      "</androidx.constraintlayout.widget.ConstraintLayout>",
      '''    <com.kdt.mcgui.MineButton
        android:id="@+id/button_crawford_account"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="Crawford Account (email)"
        android:textSize="@dimen/_12ssp"
        android:layout_marginHorizontal="@dimen/_25sdp"
        app:layout_constraintBottom_toBottomOf="@id/login_menu"
        app:layout_constraintEnd_toEndOf="@+id/login_menu"
        app:layout_constraintStart_toStartOf="@+id/login_menu"
        app:layout_constraintTop_toBottomOf="@+id/button_local_authentication" />

</androidx.constraintlayout.widget.ConstraintLayout>''')
patch(f"{JAVA}/net/kdt/pojavlaunch/fragments/SelectAuthFragment.java",
      "        mLocalButton.setOnClickListener(",
      "        view.findViewById(R.id.button_crawford_account).setOnClickListener(v -> net.crawford.CrawfordAccountFragment.open(requireActivity()));\n"
      "        mLocalButton.setOnClickListener(")

# 4. Register a join session for the Crawford server whenever the game starts.
patch(f"{JAVA}/net/kdt/pojavlaunch/MainActivity.java",
      "        Tools.launchMinecraft(this, minecraftAccount, minecraftProfile, versionId, requiredJavaVersion);",
      "        net.crawford.CrawfordAccount.startJoinSessionAsync(this, minecraftAccount, Tools.getGameDirPath(minecraftProfile), versionId);\n"
      "        Tools.launchMinecraft(this, minecraftAccount, minecraftProfile, versionId, requiredJavaVersion);")
print("Crawford accounts added.")
