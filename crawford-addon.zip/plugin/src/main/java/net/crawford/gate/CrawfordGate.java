package net.crawford.gate;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.net.InetAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.Locale;

public final class CrawfordGate extends JavaPlugin implements Listener {
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        if (getConfig().getString("server-secret", "").startsWith("PASTE")) {
            getLogger().warning("Edit plugins/CrawfordGate/config.yml and fill in supabase-url, supabase-key and server-secret, then run /crawfordgate reload");
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("crawfordcheck")) {
            if (args.length != 1) return false;
            sender.sendMessage(ChatColor.GRAY + "Checking " + args[0] + "...");
            JsonObject body = new JsonObject();
            body.addProperty("query", args[0]);
            Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
                String msg;
                try {
                    HttpResponse<String> res = call("lookup", body);
                    JsonObject json = JsonParser.parseString(res.body()).getAsJsonObject();
                    if (res.statusCode() != 200) {
                        msg = ChatColor.RED + "Lookup failed (" + res.statusCode() + ")";
                    } else if (!json.get("found").getAsBoolean()) {
                        msg = ChatColor.RED + "No Crawford account or player called " + args[0];
                    } else {
                        StringBuilder sb = new StringBuilder(ChatColor.GREEN + "--- Crawford status ---");
                        for (com.google.gson.JsonElement line : json.getAsJsonArray("lines")) {
                            sb.append("\n").append(ChatColor.GRAY).append(line.getAsString());
                        }
                        msg = sb.toString();
                    }
                } catch (Exception e) {
                    msg = ChatColor.RED + "Lookup error: " + e.getMessage();
                }
                final String out = msg;
                Bukkit.getScheduler().runTask(this, () -> sender.sendMessage(out));
            });
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            sender.sendMessage(ChatColor.GREEN + "CrawfordGate config reloaded.");
            return true;
        }
        return false;
    }

    private HttpResponse<String> call(String route, JsonObject body) throws Exception {
        String base = getConfig().getString("supabase-url", "").replaceAll("/+$", "");
        String key = getConfig().getString("supabase-key", "");
        HttpRequest req = HttpRequest.newBuilder(URI.create(base + "/functions/v1/crawford/" + route))
                .timeout(Duration.ofSeconds(8))
                .header("Content-Type", "application/json")
                .header("apikey", key)
                .header("Authorization", "Bearer " + key)
                .header("x-crawford-secret", getConfig().getString("server-secret", ""))
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();
        return http.send(req, HttpResponse.BodyHandlers.ofString());
    }

    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s.replace("\\n", "\n"));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPreLogin(AsyncPlayerPreLoginEvent event) {
        if (event.getLoginResult() != AsyncPlayerPreLoginEvent.Result.ALLOWED) return;
        String name = event.getName();
        List<String> bypass = getConfig().getStringList("bypass");
        for (String b : bypass) if (b.equalsIgnoreCase(name)) return;

        boolean onlineMode = Bukkit.getOnlineMode();
        InetAddress addr = event.getAddress();
        String checkIpSetting = getConfig().getString("check-ip", "auto").toLowerCase(Locale.ROOT);
        boolean checkIp = checkIpSetting.equals("auto") ? !onlineMode : checkIpSetting.equals("true");
        if (checkIp && getConfig().getBoolean("allow-lan-ips", true)
                && (addr.isSiteLocalAddress() || addr.isLoopbackAddress() || addr.isLinkLocalAddress())) {
            checkIp = false;
        }

        JsonObject body = new JsonObject();
        body.addProperty("name", name);
        body.addProperty("uuid", event.getUniqueId().toString());
        body.addProperty("ip", addr.getHostAddress());
        body.addProperty("onlineMode", onlineMode);
        body.addProperty("checkIp", checkIp);

        try {
            HttpResponse<String> res = call("check", body);
            if (res.statusCode() != 200) {
                getLogger().warning("Crawford check failed (" + res.statusCode() + "): " + res.body());
                event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, color(getConfig().getString("error-message", "Try again later")));
                return;
            }
            JsonObject json = JsonParser.parseString(res.body()).getAsJsonObject();
            if (json.has("allowed") && json.get("allowed").getAsBoolean()) {
                getLogger().info(name + " joined through Crawford Launcher");
                return;
            }
            String reason = json.has("reason") ? json.get("reason").getAsString() : "unknown";
            getLogger().info("Blocked " + name + " from " + addr.getHostAddress() + " (" + reason + ")");
            if (reason.equals("blocked-mods") && json.has("flagged")) {
                StringBuilder mods = new StringBuilder();
                for (com.google.gson.JsonElement m : json.getAsJsonArray("flagged")) {
                    mods.append(mods.length() == 0 ? "" : ", ").append(m.getAsString());
                }
                event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER,
                        color(getConfig().getString("blocked-mods-message", "Blocked mods: %mods%").replace("%mods%", mods)));
                return;
            }
            event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_WHITELIST, color(getConfig().getString("kick-message", "Join with Crawford Launcher")));
        } catch (Exception e) {
            getLogger().warning("Crawford check error: " + e);
            event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER, color(getConfig().getString("error-message", "Try again later")));
        }
    }
}
