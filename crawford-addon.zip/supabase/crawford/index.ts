// Crawford Launcher account service (Supabase Edge Function named "crawford").
//   POST /crawford/start             launcher: player pressed Play (proves ownership, saves status + mods)
//   POST /crawford/check             server plugin: may this player join?
//   POST /crawford/lookup            server plugin: /crawfordcheck <name>
//   POST /crawford/discord           Discord: slash command /check <name>
//   GET  /crawford/discord-register?secret=...   registers the /check command (open once in a browser)
import { createClient } from "npm:@supabase/supabase-js@2";
import nacl from "npm:tweetnacl@1.0.3";

const env = (k: string, d = "") => Deno.env.get(k) ?? d;
const admin = createClient(env("SUPABASE_URL"), env("SUPABASE_SERVICE_ROLE_KEY"), { auth: { persistSession: false } });
const SERVER_SECRET = env("CRAWFORD_SERVER_SECRET");
const SESSION_HOURS = Number(env("CRAWFORD_SESSION_HOURS", "12"));
const KICK_FLAGGED = env("CRAWFORD_KICK_FLAGGED", "true") !== "false";
const WEBHOOK = env("CRAWFORD_DISCORD_WEBHOOK");
const DISCORD_PUBLIC_KEY = env("DISCORD_PUBLIC_KEY");
const DISCORD_APP_ID = env("DISCORD_APP_ID");
const DISCORD_BOT_TOKEN = env("DISCORD_BOT_TOKEN");

// Cheat clients / cheat mods. Matched against each mod's id, name and file name, and resource pack names.
// Override with the CRAWFORD_BLOCKED_MODS secret (comma separated).
const DEFAULT_BLOCKED = [
  "wurst", "meteorclient", "meteor-client", "aristois", "liquidbounce", "bleachhack", "rusherhack",
  "futureclient", "impactclient", "inertia", "thunderhack", "coffeeclient", "boze", "sigmaclient",
  "killaura", "autoclicker", "xray", "x-ray", "freecam", "baritone", "seedcracker", "nofall", "flyhack",
  "playeresp", "tracers", "packetfly", "elytrafly", "autocrystal", "crystalaura",
];
const BLOCKED = (env("CRAWFORD_BLOCKED_MODS") ? env("CRAWFORD_BLOCKED_MODS").split(",") : DEFAULT_BLOCKED)
  .map((s) => s.toLowerCase().replace(/[^a-z0-9]/g, "")).filter((s) => s.length >= 3);

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });
const dashless = (uuid: string) => uuid.replace(/-/g, "").toLowerCase();
const clip = (v: unknown, n = 100) => String(v ?? "").slice(0, n);
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, "");

type Mod = { file: string; id?: string; name?: string; version?: string };

function cleanReport(r: any) {
  const mods: Mod[] = (Array.isArray(r?.mods) ? r.mods : []).slice(0, 300).map((m: any) => ({
    file: clip(m?.file, 120), id: clip(m?.id, 64), name: clip(m?.name, 80), version: clip(m?.version, 40),
  }));
  const packs: string[] = (Array.isArray(r?.resourcepacks) ? r.resourcepacks : []).slice(0, 300).map((p: any) => clip(p, 120));
  return {
    launcher_version: clip(r?.launcherVersion, 80), game_version: clip(r?.gameVersion, 80),
    device: clip(r?.device, 80), android: clip(r?.android, 40), mods, resourcepacks: packs,
  };
}

function findFlagged(mods: Mod[], packs: string[]): string[] {
  const hits = new Set<string>();
  const test = (label: string, ...texts: (string | undefined)[]) => {
    const hay = texts.filter(Boolean).map((t) => norm(t!));
    if (BLOCKED.some((b) => hay.some((h) => h.includes(b)))) hits.add(label);
  };
  for (const m of mods) test(m.name || m.id || m.file, m.id, m.name, m.file);
  for (const p of packs) test(`resource pack: ${p}`, p);
  return [...hits].slice(0, 25);
}

async function alert(text: string) {
  if (!WEBHOOK) return;
  await fetch(WEBHOOK, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username: "Crawford Launcher", content: text.slice(0, 1900), allowed_mentions: { parse: [] } }),
  }).catch((e) => console.error("webhook", e));
}

function clientIps(req: Request, reported?: unknown): string[] {
  const ips = new Set<string>();
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) ips.add(fwd.split(",")[0].trim());
  const cf = req.headers.get("cf-connecting-ip");
  if (cf) ips.add(cf.trim());
  if (typeof reported === "string" && /^\d{1,3}(\.\d{1,3}){3}$/.test(reported)) ips.add(reported);
  return [...ips].filter(Boolean);
}

// ---------- launcher ----------

async function start(req: Request, body: any) {
  const jwt = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
  const { data: { user }, error } = await admin.auth.getUser(jwt);
  if (error || !user) return json({ error: "Sign in to your Crawford account again" }, 401);
  if (!user.email_confirmed_at) return json({ error: "Confirm your email first" }, 403);

  if (typeof body.mcAccessToken !== "string" || body.mcAccessToken.length < 20) {
    return json({ error: "Select your Microsoft account and try again" }, 400);
  }
  const mc = await fetch("https://api.minecraftservices.com/minecraft/profile", {
    headers: { Authorization: `Bearer ${body.mcAccessToken}` },
  });
  if (mc.status === 401) return json({ error: "Microsoft sign-in expired. Re-select your account and press Play again" }, 401);
  if (!mc.ok) return json({ error: "This Microsoft account doesn't own Minecraft: Java Edition" }, 403);
  const profile = await mc.json() as { id: string; name: string };
  const mcUuid = dashless(profile.id);

  const { data: link } = await admin.from("crawford_links").select("user_id").eq("mc_uuid", mcUuid).maybeSingle();
  if (link && link.user_id !== user.id) {
    return json({ error: `${profile.name} is already linked to another Crawford account` }, 409);
  }
  await admin.from("crawford_links").upsert({ mc_uuid: mcUuid, user_id: user.id, mc_name: profile.name });

  const report = cleanReport(body.report);
  const flagged = findFlagged(report.mods, report.resourcepacks);

  await admin.from("crawford_sessions").delete().eq("mc_uuid", mcUuid);
  const expires = new Date(Date.now() + SESSION_HOURS * 3600_000).toISOString();
  const { error: insErr } = await admin.from("crawford_sessions").insert({
    user_id: user.id, mc_uuid: mcUuid, mc_name: profile.name, ips: clientIps(req, body.ipv4),
    expires_at: expires, flagged, ...report,
  });
  if (insErr) {
    console.error(insErr);
    return json({ error: "Could not save session" }, 500);
  }
  if (flagged.length) {
    const username = await usernameOf(user.id);
    await alert(`⚠️ **${profile.name}** (Crawford: ${username ?? "?"}) launched with blocked mods: ${flagged.join(", ")}`);
  }
  return json({ ok: true, name: profile.name, expiresAt: expires, flagged: KICK_FLAGGED ? flagged : [] });
}

// ---------- server plugin ----------

const serverAuthed = (req: Request) => !!SERVER_SECRET && req.headers.get("x-crawford-secret") === SERVER_SECRET;

async function check(req: Request, body: any) {
  if (!serverAuthed(req)) return json({ error: "Wrong server secret" }, 403);
  const name = String(body.name ?? "");
  if (!/^[A-Za-z0-9_]{1,16}$/.test(name)) return json({ allowed: false, reason: "invalid name" });

  const { data: rows } = await admin.from("crawford_sessions")
    .select("id, mc_uuid, mc_name, ips, flagged")
    .ilike("mc_name", name.replace(/_/g, "\\_"))
    .gt("expires_at", new Date().toISOString())
    .order("created_at", { ascending: false })
    .limit(1);
  const s = rows?.[0];
  if (!s) return json({ allowed: false, reason: "no-session" });
  if (body.onlineMode && body.uuid && dashless(String(body.uuid)) !== s.mc_uuid) {
    return json({ allowed: false, reason: "uuid-mismatch" });
  }
  if (body.checkIp && !(s.ips as string[]).includes(String(body.ip ?? ""))) {
    return json({ allowed: false, reason: "ip-mismatch" });
  }
  if (KICK_FLAGGED && s.flagged?.length) {
    await alert(`⛔ Blocked **${s.mc_name}** from joining: ${s.flagged.join(", ")}`);
    return json({ allowed: false, reason: "blocked-mods", flagged: s.flagged });
  }
  await admin.from("crawford_sessions").update({ last_join_at: new Date().toISOString(), last_join_ip: clip(body.ip, 64) }).eq("id", s.id);
  return json({ allowed: true, name: s.mc_name, uuid: s.mc_uuid });
}

// ---------- lookups (/check) ----------

async function usernameOf(userId: string) {
  const { data } = await admin.from("crawford_profiles").select("username").eq("user_id", userId).maybeSingle();
  return data?.username as string | undefined;
}

/** Find by Crawford username first, then by Minecraft name. */
async function lookupStatus(query: string) {
  const q = query.trim();
  if (!/^[A-Za-z0-9_]{1,32}$/.test(q)) return null;
  const like = q.replace(/_/g, "\\_");
  let userId: string | undefined;
  let username: string | undefined;
  let joined: string | undefined;
  const { data: prof } = await admin.from("crawford_profiles").select("user_id, username, created_at").ilike("username", like).maybeSingle();
  if (prof) {
    userId = prof.user_id; username = prof.username; joined = prof.created_at;
  } else {
    const { data: link } = await admin.from("crawford_links").select("user_id").ilike("mc_name", like).limit(1).maybeSingle();
    if (!link) return null;
    userId = link.user_id;
    const { data: p2 } = await admin.from("crawford_profiles").select("username, created_at").eq("user_id", userId).maybeSingle();
    username = p2?.username; joined = p2?.created_at;
  }
  const { data: links } = await admin.from("crawford_links").select("mc_name, mc_uuid").eq("user_id", userId);
  const { data: sessions } = await admin.from("crawford_sessions").select("*").eq("user_id", userId)
    .order("created_at", { ascending: false }).limit(1);
  return { username: username ?? "(no username)", joined, links: links ?? [], last: sessions?.[0] };
}

const ts = (iso?: string | null) => iso ? `<t:${Math.floor(new Date(iso).getTime() / 1000)}:R>` : "never";
const plainTs = (iso?: string | null) => iso ? new Date(iso).toISOString().replace("T", " ").slice(0, 16) + " UTC" : "never";

function modLines(mods: Mod[]) {
  return mods.map((m) => `${m.name || m.id || m.file}${m.version ? " " + m.version : ""}`);
}

async function lookup(req: Request, body: any) {
  if (!serverAuthed(req)) return json({ error: "Wrong server secret" }, 403);
  const st = await lookupStatus(String(body.query ?? ""));
  if (!st) return json({ found: false });
  const s = st.last;
  const lines = [
    `Crawford account: ${st.username} (created ${plainTs(st.joined)})`,
    `Minecraft: ${st.links.map((l: any) => l.mc_name).join(", ") || "none linked"}`,
  ];
  if (s) {
    const active = new Date(s.expires_at) > new Date();
    lines.push(
      `Last Play: ${plainTs(s.created_at)} — pass ${active ? "active" : "expired"}`,
      `Last joined server: ${plainTs(s.last_join_at)}`,
      `Game: ${s.game_version || "?"} | Launcher: ${s.launcher_version || "?"}`,
      `Device: ${s.device || "?"} (Android ${s.android || "?"})`,
      `Flagged: ${s.flagged?.length ? s.flagged.join(", ") : "none"}`,
      `Mods (${s.mods.length}): ${modLines(s.mods).join(", ") || "none"}`,
      `Resource packs (${s.resourcepacks.length}): ${s.resourcepacks.join(", ") || "none"}`,
    );
  } else lines.push("Has never pressed Play.");
  return json({ found: true, lines });
}

// ---------- Discord ----------

const hex = (h: string) => new Uint8Array((h.match(/.{2}/g) ?? []).map((b) => parseInt(b, 16)));

async function discord(req: Request, raw: string) {
  const sig = req.headers.get("x-signature-ed25519") ?? "";
  const time = req.headers.get("x-signature-timestamp") ?? "";
  const ok = DISCORD_PUBLIC_KEY && sig && time &&
    nacl.sign.detached.verify(new TextEncoder().encode(time + raw), hex(sig), hex(DISCORD_PUBLIC_KEY));
  if (!ok) return new Response("invalid request signature", { status: 401 });

  const i = JSON.parse(raw);
  if (i.type === 1) return json({ type: 1 }); // PING
  if (i.type !== 2 || i.data?.name !== "check") return json({ type: 4, data: { content: "Unknown command", flags: 64 } });

  const query = String(i.data.options?.find((o: any) => o.name === "name")?.value ?? "");
  const st = await lookupStatus(query);
  if (!st) return json({ type: 4, data: { content: `No Crawford account or Minecraft player called **${query}**.`, flags: 64 } });

  const s = st.last;
  const fields: any[] = [
    { name: "Minecraft", value: st.links.map((l: any) => l.mc_name).join(", ") || "none linked", inline: true },
    { name: "Account created", value: ts(st.joined), inline: true },
  ];
  let color = 0x2ebd6b;
  if (s) {
    const active = new Date(s.expires_at) > new Date();
    const mods = modLines(s.mods);
    let modText = mods.join("\n") || "none";
    if (modText.length > 1000) modText = modText.slice(0, 990) + "\n…";
    let packText = s.resourcepacks.join("\n") || "none";
    if (packText.length > 1000) packText = packText.slice(0, 990) + "\n…";
    if (s.flagged?.length) color = 0xe5484d;
    else if (!active) color = 0x8c8c8c;
    fields.push(
      { name: "Status", value: s.flagged?.length ? "⛔ Blocked mods" : active ? "✅ Pass active" : "⌛ Pass expired", inline: true },
      { name: "Last Play", value: ts(s.created_at), inline: true },
      { name: "Last joined server", value: ts(s.last_join_at), inline: true },
      { name: "Game version", value: s.game_version || "?", inline: true },
      { name: "Launcher", value: s.launcher_version || "?", inline: true },
      { name: "Device", value: `${s.device || "?"}\nAndroid ${s.android || "?"}`, inline: true },
      { name: "Flagged", value: s.flagged?.length ? s.flagged.join("\n").slice(0, 1000) : "none" },
      { name: `Mods (${mods.length})`, value: modText },
      { name: `Resource packs (${s.resourcepacks.length})`, value: packText },
    );
  } else {
    fields.push({ name: "Status", value: "Has never pressed Play" });
  }
  return json({
    type: 4,
    data: { flags: 64, embeds: [{ title: `Crawford: ${st.username}`, color, fields, footer: { text: "Crawford Launcher" } }] },
  });
}

async function discordRegister(url: URL) {
  if (!SERVER_SECRET || url.searchParams.get("secret") !== SERVER_SECRET) return new Response("Wrong secret", { status: 403 });
  if (!DISCORD_APP_ID || !DISCORD_BOT_TOKEN) return new Response("Set DISCORD_APP_ID and DISCORD_BOT_TOKEN secrets first", { status: 400 });
  const res = await fetch(`https://discord.com/api/v10/applications/${DISCORD_APP_ID}/commands`, {
    method: "PUT",
    headers: { "Content-Type": "application/json", Authorization: `Bot ${DISCORD_BOT_TOKEN}` },
    body: JSON.stringify([{
      name: "check",
      description: "Show a player's Crawford Launcher status",
      default_member_permissions: "8", // Administrators only; change in Server Settings > Integrations
      dm_permission: false,
      options: [{ type: 3, name: "name", description: "Crawford username or Minecraft name", required: true }],
    }]),
  });
  return new Response(res.ok ? "✅ /check registered. You can close this page." : `Discord said ${res.status}: ${await res.text()}`,
    { status: res.ok ? 200 : 500, headers: { "Content-Type": "text/plain; charset=utf-8" } });
}

// ---------- router ----------

Deno.serve(async (req) => {
  const url = new URL(req.url);
  const route = url.pathname.split("/").filter(Boolean).pop();
  try {
    if (req.method === "GET" && route === "discord-register") return await discordRegister(url);
    if (req.method !== "POST") return json({ error: "POST only" }, 405);
    const raw = await req.text();
    if (route === "discord") return await discord(req, raw);
    let body: any = {};
    try { body = JSON.parse(raw); } catch { /* empty */ }
    if (route === "start") return await start(req, body);
    if (route === "check") return await check(req, body);
    if (route === "lookup") return await lookup(req, body);
    return json({ error: "Unknown route" }, 404);
  } catch (e) {
    console.error(e);
    return json({ error: "Server error" }, 500);
  }
});
