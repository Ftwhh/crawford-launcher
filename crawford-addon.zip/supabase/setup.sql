-- Crawford Launcher accounts: paste this whole file into Supabase > SQL Editor and press Run.

-- Which Minecraft account belongs to which Crawford (email) account.
create table if not exists public.crawford_links (
  mc_uuid   text primary key,
  user_id   uuid not null references auth.users (id) on delete cascade,
  mc_name   text not null,
  linked_at timestamptz not null default now()
);

-- A row is created every time someone presses Play in Crawford Launcher.
create table if not exists public.crawford_sessions (
  id         bigint generated always as identity primary key,
  user_id    uuid not null references auth.users (id) on delete cascade,
  mc_uuid    text not null,
  mc_name    text not null,
  ips        text[] not null default '{}',
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create index if not exists crawford_sessions_name_idx on public.crawford_sessions (lower(mc_name), expires_at desc);
create index if not exists crawford_sessions_uuid_idx on public.crawford_sessions (mc_uuid);

-- Only the Crawford service (service role) can read or write these tables.
alter table public.crawford_links    enable row level security;
alter table public.crawford_sessions enable row level security;

-- ===== v2: launcher status, mod checks, Crawford usernames (safe to run again) =====

alter table public.crawford_sessions add column if not exists launcher_version text;
alter table public.crawford_sessions add column if not exists game_version     text;
alter table public.crawford_sessions add column if not exists device           text;
alter table public.crawford_sessions add column if not exists android          text;
alter table public.crawford_sessions add column if not exists mods             jsonb not null default '[]';
alter table public.crawford_sessions add column if not exists resourcepacks    jsonb not null default '[]';
alter table public.crawford_sessions add column if not exists flagged          text[] not null default '{}';
alter table public.crawford_sessions add column if not exists last_join_at     timestamptz;
alter table public.crawford_sessions add column if not exists last_join_ip     text;

-- Crawford usernames (picked at sign-up), so staff can /check by name.
create table if not exists public.crawford_profiles (
  user_id    uuid primary key references auth.users (id) on delete cascade,
  username   text not null,
  created_at timestamptz not null default now()
);
create unique index if not exists crawford_profiles_username_idx on public.crawford_profiles (lower(username));
alter table public.crawford_profiles enable row level security;

create or replace function public.crawford_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.raw_user_meta_data ? 'username' then
    insert into public.crawford_profiles (user_id, username)
    values (new.id, new.raw_user_meta_data ->> 'username');
  end if;
  return new;
end $$;

drop trigger if exists crawford_on_signup on auth.users;
create trigger crawford_on_signup after insert on auth.users
  for each row execute function public.crawford_new_user();

-- Accounts made before this update.
insert into public.crawford_profiles (user_id, username)
select id, raw_user_meta_data ->> 'username' from auth.users
where raw_user_meta_data ? 'username'
on conflict do nothing;
