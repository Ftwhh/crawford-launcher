package net.crawford;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.Patterns;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.kdt.mcgui.MineButton;

import net.kdt.pojavlaunch.R;
import net.kdt.pojavlaunch.Tools;

/** Screen for creating / signing in to a Crawford account with email and password. */
public class CrawfordAccountFragment extends Fragment {
    public static final String TAG = "CRAWFORD_ACCOUNT_FRAGMENT";

    private static final String PRIVACY = "While signed in, pressing Play shares your Minecraft name, game version, launcher version, phone model, and the names of your mods and resource packs with the Crawford server staff. Sign out to stop sharing.";

    private LinearLayout mRoot;
    private final Handler mMainHandler = new Handler(Looper.getMainLooper());

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Context ctx = requireContext();
        ScrollView scroll = new ScrollView(ctx);
        scroll.setBackgroundColor(ctx.getResources().getColor(R.color.background_app));
        scroll.setFillViewport(true);
        mRoot = new LinearLayout(ctx);
        mRoot.setOrientation(LinearLayout.VERTICAL);
        mRoot.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = dp(24);
        mRoot.setPadding(pad, pad, pad, pad);
        scroll.addView(mRoot, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        render();
        return scroll;
    }

    private void render() {
        mRoot.removeAllViews();
        Context ctx = requireContext();
        addTitle("Crawford Account");
        if (!CrawfordAccount.isConfigured()) {
            addText("Crawford accounts aren't set up in this build. The server owner needs to add the Supabase settings and rebuild the app.");
            return;
        }
        if (CrawfordAccount.isSignedIn(ctx)) {
            String name = CrawfordAccount.getUsername(ctx);
            addText("Signed in as " + (name.isEmpty() ? "" : name + "\n") + CrawfordAccount.getEmail(ctx));
            addText("When you press Play with your Microsoft account selected, you'll be let in to the Crawford server.");
            addText(PRIVACY);
            addButton("Sign out", v -> { CrawfordAccount.signOut(ctx); render(); });
            addButton("Back", v -> requireActivity().onBackPressed());
            return;
        }
        addText("Sign in with your email to join the Crawford server. You also need a Microsoft account that owns Minecraft: Java Edition.");
        EditText username = addField("Username (for sign up)", InputType.TYPE_CLASS_TEXT);
        EditText email = addField("Email", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText password = addField("Password (8+ characters)", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        addText(PRIVACY);
        TextView status = addText("");

        addButton("Sign in", v -> {
            String e = email.getText().toString().trim();
            String p = password.getText().toString();
            if (!Patterns.EMAIL_ADDRESS.matcher(e).matches() || p.isEmpty()) {
                status.setText("Enter your email and password.");
                return;
            }
            status.setText("Signing in…");
            runAsync(() -> {
                CrawfordAccount.signIn(ctx, e, p);
                return null;
            }, err -> {
                if (err == null) render();
                else if (err.contains("not confirmed")) status.setText("Check your inbox and tap the confirmation link first.");
                else status.setText(err);
            });
        });
        addButton("Create account", v -> {
            String u = username.getText().toString().trim();
            String e = email.getText().toString().trim();
            String p = password.getText().toString();
            if (!u.matches("^[a-zA-Z0-9_]{3,16}$")) {
                status.setText("Username: 3–16 letters, numbers or _.");
                return;
            }
            if (!Patterns.EMAIL_ADDRESS.matcher(e).matches()) {
                status.setText("Enter a valid email.");
                return;
            }
            if (p.length() < 8) {
                status.setText("Password must be at least 8 characters.");
                return;
            }
            status.setText("Creating account…");
            runAsync(() -> {
                CrawfordAccount.signUp(e, p, u);
                return null;
            }, err -> status.setText(err == null
                    ? "Account created. Open the email we sent to " + e + ", tap the link, then sign in here."
                    : err.contains("Database error") ? "That username is already taken." : err));
        });
    }

    private interface IoTask { Object run() throws Exception; }
    private interface Done { void done(@Nullable String error); }

    private void runAsync(IoTask task, Done done) {
        new Thread(() -> {
            String error = null;
            try { task.run(); } catch (Exception e) {
                error = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            final String finalError = error;
            mMainHandler.post(() -> { if (isAdded()) done.done(finalError); });
        }, "CrawfordAuth").start();
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private LinearLayout.LayoutParams rowParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        return lp;
    }

    private void addTitle(String text) {
        TextView t = new TextView(requireContext());
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        t.setGravity(Gravity.CENTER);
        mRoot.addView(t, rowParams());
    }

    private TextView addText(String text) {
        TextView t = new TextView(requireContext());
        t.setText(text);
        t.setTextColor(0xFFB2B2B2);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        mRoot.addView(t, rowParams());
        return t;
    }

    private EditText addField(String hint, int inputType) {
        EditText e = new EditText(requireContext());
        e.setHint(hint);
        e.setInputType(inputType);
        e.setSingleLine(true);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(0xFF808080);
        mRoot.addView(e, rowParams());
        return e;
    }

    private Button addButton(String text, View.OnClickListener listener) {
        MineButton b = new MineButton(requireContext());
        b.setText(text);
        b.setOnClickListener(listener);
        mRoot.addView(b, rowParams());
        return b;
    }

    /** Opens this screen. */
    public static void open(androidx.fragment.app.FragmentActivity activity) {
        Tools.swapFragment(activity, CrawfordAccountFragment.class, TAG, null);
    }
}
