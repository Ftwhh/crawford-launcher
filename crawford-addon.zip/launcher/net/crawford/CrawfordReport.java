package net.crawford;

import android.os.Build;

import net.kdt.pojavlaunch.BuildConfig;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Builds the launcher status that is sent to the server owner when the player presses Play:
 * launcher version, game version, device, installed mods (read from inside each jar, so renaming
 * a file doesn't hide it) and resource packs.
 */
final class CrawfordReport {
    private static final int MAX_ITEMS = 300;
    private static final Pattern TOML_MOD_ID = Pattern.compile("modId\\s*=\\s*\"([^\"]+)\"");
    private static final Pattern TOML_NAME = Pattern.compile("displayName\\s*=\\s*\"([^\"]+)\"");
    private static final Pattern TOML_VERSION = Pattern.compile("(?m)^\\s*version\\s*=\\s*\"([^\"]+)\"");

    private CrawfordReport() {}

    static JSONObject build(File gameDir, String gameVersion) {
        JSONObject r = new JSONObject();
        try {
            r.put("launcherVersion", BuildConfig.VERSION_NAME);
            r.put("gameVersion", gameVersion == null ? "" : gameVersion);
            r.put("device", (Build.MANUFACTURER + " " + Build.MODEL).trim());
            r.put("android", Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")");
            r.put("mods", gameDir == null ? new JSONArray() : mods(new File(gameDir, "mods")));
            r.put("resourcepacks", gameDir == null ? new JSONArray() : names(new File(gameDir, "resourcepacks")));
        } catch (Exception ignored) {
        }
        return r;
    }

    private static JSONArray names(File dir) {
        JSONArray out = new JSONArray();
        File[] files = dir.listFiles();
        if (files == null) return out;
        Arrays.sort(files);
        for (File f : files) {
            if (out.length() >= MAX_ITEMS) break;
            if (!f.getName().startsWith(".")) out.put(f.getName());
        }
        return out;
    }

    private static JSONArray mods(File dir) {
        JSONArray out = new JSONArray();
        File[] files = dir.listFiles();
        if (files == null) return out;
        Arrays.sort(files);
        for (File f : files) {
            if (out.length() >= MAX_ITEMS) break;
            String n = f.getName().toLowerCase();
            if (!f.isFile() || !(n.endsWith(".jar") || n.endsWith(".zip") || n.endsWith(".litemod"))) continue;
            JSONObject m = new JSONObject();
            try {
                m.put("file", f.getName());
                readMetadata(f, m);
            } catch (Exception ignored) {
            }
            out.put(m);
        }
        return out;
    }

    private static void readMetadata(File jar, JSONObject m) {
        try (ZipFile zip = new ZipFile(jar)) {
            for (String json : new String[]{"fabric.mod.json", "quilt.mod.json"}) {
                ZipEntry e = zip.getEntry(json);
                if (e == null) continue;
                JSONObject meta = new JSONObject(read(zip.getInputStream(e)));
                JSONObject q = meta.optJSONObject("quilt_loader");
                if (q != null) {
                    m.put("id", q.optString("id"));
                    m.put("version", q.optString("version"));
                    JSONObject md = q.optJSONObject("metadata");
                    if (md != null) m.put("name", md.optString("name"));
                } else {
                    m.put("id", meta.optString("id"));
                    m.put("name", meta.optString("name"));
                    m.put("version", meta.optString("version"));
                }
                return;
            }
            for (String toml : new String[]{"META-INF/neoforge.mods.toml", "META-INF/mods.toml"}) {
                ZipEntry e = zip.getEntry(toml);
                if (e == null) continue;
                String text = read(zip.getInputStream(e));
                put(m, "id", TOML_MOD_ID.matcher(text));
                put(m, "name", TOML_NAME.matcher(text));
                put(m, "version", TOML_VERSION.matcher(text));
                return;
            }
        } catch (Exception ignored) {
            // Not a readable jar; the file name is still reported.
        }
    }

    private static void put(JSONObject m, String key, Matcher matcher) throws Exception {
        if (matcher.find()) m.put(key, matcher.group(1));
    }

    private static String read(InputStream is) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n, total = 0;
        while ((n = is.read(buf)) != -1 && total < 512 * 1024) {
            out.write(buf, 0, n);
            total += n;
        }
        is.close();
        return out.toString("UTF-8");
    }
}
