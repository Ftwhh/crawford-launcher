package net.crawford;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import net.kdt.pojavlaunch.BuildConfig;
import net.kdt.pojavlaunch.value.MinecraftAccount;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Crawford account: email sign-up/sign-in (Supabase Auth) and join sessions for the Crawford server. */
public final class CrawfordAccount {
    private static final String TAG = "Crawford";
    private static final String PREFS = "crawford_account";

    private CrawfordAccount() {}

    public static boolean isConfigured() {
        return !BuildConfig.CRAWFORD_SUPABASE_URL.isEmpty() && !BuildConfig.CRAWFORD_SUPABASE_KEY.isEmpty();
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean isSignedIn(Context ctx) {
        return prefs(ctx).getString("refresh_token", null) != null;
    }

    public static String getEmail(Context ctx) {
        return prefs(ctx).getString("email", "");
    }

    public static String getUsername(Context ctx) {
        return prefs(ctx).getString("username", "");
    }

    public static void signOut(Context ctx) {
        prefs(ctx).edit().clear().apply();
    }

    /** Creates an account. Supabase sends a confirmation email; the user must click it before signing in. */
    public static void signUp(String email, String password, String username) throws IOException {
        JSONObject body = new JSONObject();
        try {
            body.put("email", email);
            body.put("password", password);
            body.put("data", new JSONObject().put("username", username));
        } catch (Exception e) { throw new IOException(e); }
        request("POST", "/auth/v1/signup", null, body);
    }

    public static void signIn(Context ctx, String email, String password) throws IOException {
        JSONObject body = new JSONObject();
        try {
            body.put("email", email);
            body.put("password", password);
        } catch (Exception e) { throw new IOException(e); }
        saveSession(ctx, request("POST", "/auth/v1/token?grant_type=password", null, body));
    }

    /** @return a valid access token, refreshing it if needed. */
    private static String accessToken(Context ctx) throws IOException {
        SharedPreferences p = prefs(ctx);
        String token = p.getString("access_token", null);
        long expiresAt = p.getLong("expires_at", 0);
        if (token != null && System.currentTimeMillis() / 1000 < expiresAt - 60) return token;
        String refresh = p.getString("refresh_token", null);
        if (refresh == null) throw new IOException("Not signed in to a Crawford account");
        JSONObject body = new JSONObject();
        try { body.put("refresh_token", refresh); } catch (Exception e) { throw new IOException(e); }
        JSONObject res;
        try {
            res = request("POST", "/auth/v1/token?grant_type=refresh_token", null, body);
        } catch (HttpError e) {
            if (e.code == 400 || e.code == 401) signOut(ctx); // refresh token revoked or expired
            throw e;
        }
        saveSession(ctx, res);
        return res.optString("access_token");
    }

    private static void saveSession(Context ctx, JSONObject res) {
        JSONObject user = res.optJSONObject("user");
        String email = user != null ? user.optString("email") : getEmail(ctx);
        String username = getUsername(ctx);
        if (user != null && user.optJSONObject("user_metadata") != null) {
            username = user.optJSONObject("user_metadata").optString("username", username);
        }
        prefs(ctx).edit()
                .putString("access_token", res.optString("access_token"))
                .putString("refresh_token", res.optString("refresh_token"))
                .putLong("expires_at", res.optLong("expires_at", System.currentTimeMillis() / 1000 + 3000))
                .putString("email", email)
                .putString("username", username)
                .apply();
    }

    /**
     * Tells the Crawford service that this player just launched the game through Crawford Launcher,
     * so the Crawford server lets them in. Proves Minecraft ownership with the Microsoft account's token.
     * @return the Minecraft name the session was created for.
     */
    public static String startJoinSession(Context ctx, MinecraftAccount account, java.io.File gameDir, String gameVersion) throws IOException {
        if (account == null || !account.isMicrosoft || account.isLocal()) {
            throw new IOException("Select your Microsoft account to join the Crawford server");
        }
        JSONObject body = new JSONObject();
        try {
            body.put("mcAccessToken", account.accessToken);
            body.put("report", CrawfordReport.build(gameDir, gameVersion));
            String ipv4 = publicIpv4();
            if (ipv4 != null) body.put("ipv4", ipv4);
        } catch (Exception e) { throw new IOException(e); }
        JSONObject res = request("POST", "/functions/v1/crawford/start", accessToken(ctx), body);
        String name = res.optString("name", account.username);
        org.json.JSONArray flagged = res.optJSONArray("flagged");
        if (flagged != null && flagged.length() > 0) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < flagged.length(); i++) sb.append(i == 0 ? "" : ", ").append(flagged.optString(i));
            throw new IOException("blocked mods found (" + sb + "). Remove them to join.");
        }
        return name;
    }

    /** Runs startJoinSession in the background when the game launches. Never blocks or breaks the launch. */
    public static void startJoinSessionAsync(Context ctx, MinecraftAccount account, java.io.File gameDir, String gameVersion) {
        if (!isConfigured() || !isSignedIn(ctx)) return;
        final Context app = ctx.getApplicationContext();
        new Thread(() -> {
            try {
                String name = startJoinSession(app, account, gameDir, gameVersion);
                Log.i(TAG, "Crawford server access ready for " + name);
                toast(app, "Crawford server: ready to join as " + name);
            } catch (Exception e) {
                Log.w(TAG, "Could not start Crawford join session", e);
                toast(app, "Crawford server: " + e.getMessage());
            }
        }, "CrawfordJoinSession").start();
    }

    private static void toast(Context ctx, String msg) {
        new android.os.Handler(android.os.Looper.getMainLooper()).post(() ->
                android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_LONG).show());
    }

    private static String publicIpv4() {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL("https://api.ipify.org").openConnection();
            c.setConnectTimeout(4000);
            c.setReadTimeout(4000);
            if (c.getResponseCode() != 200) return null;
            String ip = readAll(c.getInputStream()).trim();
            return ip.matches("^\\d{1,3}(\\.\\d{1,3}){3}$") ? ip : null;
        } catch (Exception e) {
            return null;
        }
    }

    public static class HttpError extends IOException {
        public final int code;
        HttpError(int code, String message) { super(message); this.code = code; }
    }

    private static JSONObject request(String method, String path, String bearer, JSONObject body) throws IOException {
        if (!isConfigured()) throw new IOException("Crawford accounts are not set up in this build");
        HttpURLConnection c = (HttpURLConnection) new URL(BuildConfig.CRAWFORD_SUPABASE_URL.replaceAll("/+$", "") + path).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(10000);
        c.setReadTimeout(20000);
        c.setRequestProperty("apikey", BuildConfig.CRAWFORD_SUPABASE_KEY);
        c.setRequestProperty("Authorization", "Bearer " + (bearer != null ? bearer : BuildConfig.CRAWFORD_SUPABASE_KEY));
        c.setRequestProperty("Content-Type", "application/json");
        if (body != null) {
            c.setDoOutput(true);
            try (OutputStream os = c.getOutputStream()) {
                os.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
        }
        int code = c.getResponseCode();
        InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String text = is == null ? "" : readAll(is);
        JSONObject json;
        try {
            json = text.isEmpty() ? new JSONObject() : new JSONObject(text);
        } catch (Exception e) {
            json = new JSONObject();
        }
        if (code >= 400) {
            String msg = json.optString("error_description",
                    json.optString("msg", json.optString("message", json.optString("error", "Request failed (" + code + ")"))));
            throw new HttpError(code, msg);
        }
        return json;
    }

    private static String readAll(InputStream is) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = is.read(buf)) != -1) out.write(buf, 0, n);
        is.close();
        return out.toString("UTF-8");
    }
}
